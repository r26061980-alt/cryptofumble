# Crypto Dream Machine — двуязычный проект (RU + EN)

## Структура
```
ru/               — русская версия (cryptomashina.com или что выберешь)
  index.html
  netlify/functions/price.js
  netlify/functions/search.js
  netlify.toml
en/               — английская версия (cryptodreammachine.com или что выберешь)
  index.html
  netlify/functions/price.js
  netlify/functions/search.js
  netlify.toml
```

Обе папки полностью независимы — отдельный HTML, отдельные serverless-функции
(идентичный код, просто задеплоены дважды под разными сайтами).

## Как задеплоить как ДВА сайта из ОДНОГО репозитория

1. Создать один GitHub-репозиторий, залить в него обе папки `ru/` и `en/` как есть.

2. В Netlify:
   - **Add new site → Import an existing project** → выбрать репозиторий
   - В Site settings → Build & deploy → **Base directory**: `ru`,
     **Publish directory**: `ru` → это будет русский сайт
   - Ещё раз **Add new site → Import an existing project** на тот же репозиторий
   - **Base directory**: `en`, **Publish directory**: `en` → английский сайт

3. Каждый сайт получит свой `*.netlify.app` адрес — уже можно проверить что живой.

4. Купить 2 домена (Porkbun/Namecheap, НЕ .ru — см. объяснение в чате про
   изменения в регистрации .ru с 1 сентября 2026).

5. В каждом Netlify-сайте: Site settings → Domain management → Add custom domain
   → делегировать nameservers на Netlify (проще всего) → подождать DNS →
   SSL выпустится автоматически.

6. Готово — на реальном домене живые цены заработают сами: фронтенд стучится
   в /api/price на СВОЁМ домене (без CORS), функция уже сама ходит в CoinGecko
   сервер-сервер.

## Если нужно поправить текст на одном языке, а не на другом
Оба index.html — независимые файлы. Правишь нужный, второй не трогаешь.
Если меняешь логику (JS) — меняй в обоих, они сейчас идентичны по функциональности,
отличается только текст.
